function [Vin,Vout] = bwd_euler(mode,number_of_steps,dt,C,G,F,V,asgmt_part)

for i = 1:number_of_steps
    
    if mode == "step"
        if i*dt >= 0.03
            Vin(i) = 1;
        else
            Vin(i) = 0;
        end
    elseif mode == "sine01"
        f = 1;
        Vin(i) = sin(2*pi*f*i*dt);
    elseif mode == "sine02"
        f = 1/0.03;
        Vin(i) = sin(2*pi*f*i*dt);
    elseif mode == "sine03"
        f = 1/0.2;
        Vin(i) = sin(2*pi*f*i*dt); 
    elseif mode == "gaussian"
        Vin(i) = 1 * exp ( - ( i * dt - 0.06 ) ^ 2 / ( 2 * ( 0.03 ) ^ 2 ) ) ;         
    end
    
    if asgmt_part == 5
        In = 0.001*randn(1);
        F = [Vin(i);0;0;0;In;0];
        V_old = V;
        V = ( C / dt + G ) \ ( F + ( C * V_old ) / dt );
        Vout(i) = V(5);   
    else
        V_old = V;
        V = ( C / dt + G ) \ ( F * Vin(i) + ( C * V_old ) / dt );
        Vout(i) = V(5);   
    end
    
    if i >= 2
        plot([(i-1)*dt i*dt], [Vin(i-1) Vin(i)],'-b');
        hold on;
        plot([(i-1)*dt i*dt], [Vout(i-1) Vout(i)],'-r');
    end
   
end

end
