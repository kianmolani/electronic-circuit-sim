function [sigma_matrix,Vmap,Ex,Ey,Jx,Jy,I] = compute_params(nx,ny,L_b,W_b,sigma_inside,sigma_outside,bottle_neck_width,V0)

box(1,1)=nx/2; box(1,2)=W_b/2; box(1,3)=L_b; box(1,4)=W_b;
box(2,1)=nx/2; box(2,2)=ny-W_b/2; box(2,3)=L_b; box(2,4)=W_b;  
bottle_neck_width_true_val = ((box(2,2)-box(2,4)/2)-(box(1,2)+box(1,4)/2));

if bottle_neck_width ~= 1
    bottle_neck_width_diff = bottle_neck_width_true_val * bottle_neck_width - bottle_neck_width_true_val;
    box(1,1)=nx/2; box(1,2)=W_b/2-bottle_neck_width_diff/2; box(1,3)=L_b; box(1,4)=W_b-bottle_neck_width_diff/2; 
    box(2,1)=nx/2; box(2,2)=(ny-W_b/2)+bottle_neck_width_diff/2; box(2,3)=L_b; box(2,4)=W_b-bottle_neck_width_diff/2; 
end

% update sigma matrix w/ box position information

sigma_matrix(1:ny,1:nx) = sigma_outside;
box1 = box(1,:); box2 = box(2,:);
for i=1:ny
    for j=1:nx     
        if( j > ( box1(1) - box1(3)/2 ) && j < ( box1(1) + box1(3)/2 ) && ( i < ( box1(2) + box1(4)/2 ) || i > ( box2(2) - box2(4)/2 ) ) )
            sigma_matrix(i,j) = sigma_inside;
        end
    end
end

G = sparse(nx*ny); B = sparse(1,nx*ny);

% for source on implementation of code below, see slide 37 of professor's week 04 lecture slides

for i=1:ny 
    for j=1:nx 
        n = i + (j - 1) * ny;
        if j==1 
            G(n,:)=0;
            G(n,n)=1;
            B(n)=V0;
        elseif j==nx
            G(n,:)=0;
            G(n,n)=1;
        elseif i==1 
            nxm = i + (j - 2) * ny;
            nxp = i + (j) * ny;
            nyp = i + 1 + (j - 1) * ny;
            
            rxm = (sigma_matrix(i,j)+sigma_matrix(i,j-1))/2;
            rxp = (sigma_matrix(i,j)+sigma_matrix(i,j+1))/2;
            rym = (sigma_matrix(i,j)+sigma_matrix(i+1,j))/2;
            
            G(n,n) = -(rxm+rxp+rym);
            G(n,nxm) = rxm;
            G(n,nxp) = rxp;
            G(n,nyp) = rym;
        elseif i==ny
            nxm = i + (j - 2) * ny;
            nxp = i + (j) * ny;
            nym = i - 1 + (j - 1) * ny;
            
            rxm = (sigma_matrix(i, j) + sigma_matrix(i,j-1))/2;
            rxp = (sigma_matrix(i, j) + sigma_matrix(i,j+1))/2;
            rym = (sigma_matrix(i, j) + sigma_matrix(i-1,j))/2;
            
            G(n,n) = -(rxm+rxp+rym);
            G(n,nxm) = rxm;
            G(n,nxp) = rxp;
            G(n,nym) = rym;
        else
            nxm = i + (j - 2) * ny;
            nxp = i + (j) * ny;
            nym = i - 1 + (j - 1) * ny;
            nyp = i + 1 + (j - 1) * ny;

            rxm = (sigma_matrix(i,j) + sigma_matrix(i,j-1))/2;
            rxp = (sigma_matrix(i,j) + sigma_matrix(i,j+1))/2;
            rym = (sigma_matrix(i,j) + sigma_matrix(i-1,j))/2;
            ryp = (sigma_matrix(i,j) + sigma_matrix(i+1,j))/2;

            G(n,n) = -(rxm+rxp+rym+ryp);
            G(n,nxm) = rxm;
            G(n,nxp) = rxp;
            G(n,nym) = rym;
            G(n,nyp) = ryp;
        end
    end
end

V = G\B';

Vmap = zeros(ny,nx);

for i=1:ny
    for j=1:nx
        n = i + (j - 1) * ny;
        Vmap(i, j) = V(n);
    end
end

[Ex,Ey]=gradient(Vmap); 
Ex=-Ex; Ey=-Ey;
Jx=Ex.*sigma_matrix; Jy=Ey.*sigma_matrix;
I=sum(Jx(1:ny,1)); % current flow through bottle-neck

end
